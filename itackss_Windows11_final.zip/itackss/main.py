import sys, json, os
from pathlib import Path
from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QFont, QAction
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFrame, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QListWidget, QListWidgetItem, QStackedWidget,
    QFileDialog, QLineEdit, QMessageBox, QSlider, QSplitter
)
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
try:
    from PySide6.QtWebEngineWidgets import QWebEngineView
    WEB_OK = True
except Exception:
    WEB_OK = False

APP_DIR = Path.home() / ".itackss"
APP_DIR.mkdir(exist_ok=True)
LINKS_FILE = APP_DIR / "music_links.json"

STYLE = """
QMainWindow, QWidget { background:#111013; color:#eee9ec; font-family:'Segoe UI'; font-size:14px; }
QFrame#sidebar { background:#19171b; border:1px solid #302a30; border-radius:18px; }
QFrame#panel { background:#1b191e; border:1px solid #302a30; border-radius:18px; }
QLabel#brand { color:#f1dce4; font-size:25px; font-family:'Georgia'; letter-spacing:2px; }
QLabel#muted { color:#9d929a; }
QPushButton { background:#29242b; color:#eee9ec; border:1px solid #39313a; border-radius:11px; padding:10px 14px; }
QPushButton:hover { background:#3a2b35; border-color:#9b687e; }
QPushButton#active { background:#503644; border:1px solid #a8758c; color:#fff3f7; }
QLineEdit { background:#211e23; border:1px solid #403640; border-radius:10px; padding:11px; color:#fff; }
QListWidget { background:transparent; border:0; outline:0; }
QListWidget::item { padding:12px; border-radius:9px; }
QListWidget::item:selected { background:#49313d; color:#fff; }
QSlider::groove:horizontal { height:5px; background:#51434c; border-radius:2px; }
QSlider::handle:horizontal { background:#d5a1b5; width:13px; margin:-5px 0; border-radius:6px; }
"""

class PlayerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("itackss")
        self.resize(1250, 790)
        self.setMinimumSize(980, 650)
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self.audio.setVolume(0.65)
        self.tracks = []
        self.links = self.load_links()
        self.current_page = 0
        self.build_ui()
        self.player.positionChanged.connect(self.update_position)
        self.player.durationChanged.connect(self.update_duration)

    def load_links(self):
        try:
            return json.loads(LINKS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return []

    def save_links(self):
        LINKS_FILE.write_text(json.dumps(self.links, ensure_ascii=False, indent=2), encoding="utf-8")

    def build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        outer = QHBoxLayout(central)
        outer.setContentsMargins(14,14,14,14)
        outer.setSpacing(14)

        side = QFrame(); side.setObjectName("sidebar"); side.setFixedWidth(220)
        sv = QVBoxLayout(side); sv.setContentsMargins(16,20,16,16); sv.setSpacing(9)
        brand = QLabel("itackss"); brand.setObjectName("brand")
        sv.addWidget(brand)
        sub = QLabel("Слушай. Наслаждайся."); sub.setObjectName("muted")
        sv.addWidget(sub); sv.addSpacing(20)
        self.nav_buttons = []
        navs = [("⌂", "Главная"), ("⌕", "Поиск"), ("▤", "Библиотека"), ("♫", "Плейлисты"), ("♡", "Избранное"), ("↓", "Скачанные"), ("◎", "Интернет")]
        for idx, (ico, name) in enumerate(navs):
            b = QPushButton(f"{ico}   {name}")
            b.setObjectName("nav")
            b.clicked.connect(lambda checked=False, i=idx: self.show_page(i))
            sv.addWidget(b); self.nav_buttons.append(b)
        sv.addSpacing(5)
        self.links_button = QPushButton("↗   Мои ссылки")
        self.links_button.setObjectName("active")
        self.links_button.setMinimumHeight(48)
        self.links_button.clicked.connect(lambda: self.show_page(7))
        sv.addWidget(self.links_button)
        sv.addStretch()
        note = QLabel("✿  тёмная сторона музыки")
        note.setObjectName("muted")
        sv.addWidget(note)
        outer.addWidget(side)

        right = QVBoxLayout(); right.setSpacing(12)
        header = QHBoxLayout()
        self.search = QLineEdit(); self.search.setPlaceholderText("Поиск музыки, исполнителей, альбомов...")
        header.addWidget(self.search, 1)
        add = QPushButton("+ Добавить музыку"); add.clicked.connect(self.add_music)
        header.addWidget(add)
        right.addLayout(header)

        self.stack = QStackedWidget()
        right.addWidget(self.stack, 1)
        self.pages = []
        for title, desc in [
            ("Добро пожаловать в itackss", "Твоя музыка — в одном атмосферном пространстве."),
            ("Поиск", "Ищи по своей локальной музыкальной библиотеке."),
            ("Библиотека", "Добавляй аудиофайлы с компьютера и слушай их здесь."),
            ("Мои плейлисты", "Твои подборки будут собраны в одном месте."),
            ("Избранное", "Сохраняй любимые композиции."),
            ("Скачанные", "Локальные аудиофайлы на этом устройстве."),
            ("Интернет", "Открывай музыкальные сервисы прямо из приложения."),
            ("Мои ссылки", "Сохраняй ссылки на песни и плейлисты из разных сервисов.")
        ]:
            page = QWidget(); lay = QVBoxLayout(page); lay.setContentsMargins(8,8,8,8); lay.setSpacing(12)
            heading = QLabel(title); heading.setStyleSheet("font-size:26px;font-weight:600;color:#f4e9ee;")
            text = QLabel(desc); text.setObjectName("muted")
            lay.addWidget(heading); lay.addWidget(text)
            self.pages.append((page, lay))
            self.stack.addWidget(page)

        # Home content
        home, hl = self.pages[0]
        hero = QFrame(); hero.setObjectName("panel")
        hv = QVBoxLayout(hero); hv.setContentsMargins(24,24,24,24)
        kicker = QLabel("YOUR PERSONAL MUSIC SPACE"); kicker.setObjectName("muted")
        title = QLabel("Музыка, в которой хочется остаться")
        title.setStyleSheet("font-size:29px;font-family:Georgia;color:#efd9e2;")
        hv.addWidget(kicker); hv.addWidget(title)
        hv.addWidget(QLabel("Добавь свои треки или открой сохранённые ссылки на любимые сервисы."))
        hl.addWidget(hero)
        quick = QHBoxLayout()
        for label, fn in [("Добавить аудиофайлы", self.add_music), ("Мои ссылки", lambda: self.show_page(7)), ("Открыть сервисы", lambda: self.show_page(6))]:
            b=QPushButton(label); b.setMinimumHeight(54); b.clicked.connect(fn); quick.addWidget(b)
        hl.addLayout(quick); hl.addStretch()

        # Library list
        self.track_list = QListWidget()
        self.track_list.itemDoubleClicked.connect(self.play_selected)
        self.pages[2][1].addWidget(self.track_list, 1)
        self.pages[1][1].addWidget(QLabel("Поиск фильтрует добавленные аудиофайлы."))

        # Internet service shortcuts
        services = QHBoxLayout()
        for name, url in [("Яндекс Музыка","https://music.yandex.ru"),("SoundCloud","https://soundcloud.com"),("Spotify","https://open.spotify.com"),("YouTube","https://youtube.com"),("YouTube Music","https://music.youtube.com")]:
            b=QPushButton(name); b.clicked.connect(lambda checked=False, u=url: self.open_url(u)); services.addWidget(b)
        self.pages[6][1].addLayout(services)
        if WEB_OK:
            self.web = QWebEngineView()
            self.pages[6][1].addWidget(self.web, 1)
        else:
            self.pages[6][1].addWidget(QLabel("Для встроенного браузера установи PySide6-Addons. Ссылки можно открыть в системном браузере."))

        # Links page
        links_page, ll = self.pages[7]
        row = QHBoxLayout()
        self.link_input = QLineEdit(); self.link_input.setPlaceholderText("Вставь ссылку на песню или плейлист (https://...)")
        save = QPushButton("＋ Сохранить ссылку"); save.clicked.connect(self.add_link)
        row.addWidget(self.link_input, 1); row.addWidget(save)
        ll.addLayout(row)
        self.link_list = QListWidget()
        self.link_list.itemDoubleClicked.connect(self.open_selected_link)
        ll.addWidget(self.link_list, 1)
        controls = QHBoxLayout()
        open_link = QPushButton("Открыть"); open_link.clicked.connect(self.open_selected_link)
        remove = QPushButton("Удалить"); remove.clicked.connect(self.remove_link)
        controls.addWidget(open_link); controls.addWidget(remove); controls.addStretch()
        ll.addLayout(controls)
        self.refresh_links()

        # Bottom player bar
        bar = QFrame(); bar.setObjectName("panel")
        bv = QHBoxLayout(bar); bv.setContentsMargins(16,10,16,10)
        self.now = QLabel("♫   Ничего не воспроизводится"); self.now.setMinimumWidth(230)
        bv.addWidget(self.now, 1)
        self.prev_btn = QPushButton("◀"); self.prev_btn.clicked.connect(self.prev_track)
        self.play_btn = QPushButton("▶"); self.play_btn.clicked.connect(self.toggle_play)
        self.next_btn = QPushButton("▶|"); self.next_btn.clicked.connect(self.next_track)
        bv.addWidget(self.prev_btn); bv.addWidget(self.play_btn); bv.addWidget(self.next_btn)
        self.position = QSlider(Qt.Horizontal); self.position.setRange(0,1000); self.position.sliderMoved.connect(self.seek)
        bv.addWidget(self.position, 2)
        self.volume = QSlider(Qt.Horizontal); self.volume.setRange(0,100); self.volume.setValue(65); self.volume.setMaximumWidth(110)
        self.volume.valueChanged.connect(lambda v: self.audio.setVolume(v/100))
        bv.addWidget(QLabel("VOL")); bv.addWidget(self.volume)
        right.addWidget(bar)
        outer.addLayout(right, 1)

        self.search.textChanged.connect(self.filter_tracks)
        self.setStyleSheet(STYLE)
        self.show_page(0)

    def show_page(self, index):
        self.stack.setCurrentIndex(index)
        self.current_page = index
        for i,b in enumerate(self.nav_buttons):
            b.setObjectName("active" if index == i else "nav")
            b.style().unpolish(b); b.style().polish(b)
        self.links_button.setObjectName("active" if index == 7 else "nav")
        self.links_button.style().unpolish(self.links_button); self.links_button.style().polish(self.links_button)

    def add_music(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Добавить музыку", "", "Аудио (*.mp3 *.wav *.flac *.m4a *.ogg *.aac)")
        for f in files:
            if f not in self.tracks:
                self.tracks.append(f)
        self.refresh_tracks()
        self.show_page(2)

    def refresh_tracks(self):
        self.track_list.clear()
        for f in self.tracks:
            self.track_list.addItem(QListWidgetItem(Path(f).stem))

    def filter_tracks(self, query):
        if hasattr(self, "track_list"):
            for i in range(self.track_list.count()):
                self.track_list.item(i).setHidden(query.lower() not in self.track_list.item(i).text().lower())

    def play_selected(self, item):
        idx = self.track_list.row(item)
        if 0 <= idx < len(self.tracks):
            self.current_track = idx
            self.player.setSource(QUrl.fromLocalFile(self.tracks[idx]))
            self.player.play()
            self.now.setText("♫   " + Path(self.tracks[idx]).stem)
            self.play_btn.setText("Ⅱ")

    def toggle_play(self):
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause(); self.play_btn.setText("▶")
        elif self.player.source().isValid():
            self.player.play(); self.play_btn.setText("Ⅱ")
        elif self.tracks:
            self.current_track = 0
            self.player.setSource(QUrl.fromLocalFile(self.tracks[0])); self.player.play()
            self.now.setText("♫   " + Path(self.tracks[0]).stem); self.play_btn.setText("Ⅱ")

    def prev_track(self):
        if self.tracks:
            self.current_track = max(0, getattr(self, "current_track", 0)-1)
            self.start_track()

    def next_track(self):
        if self.tracks:
            self.current_track = (getattr(self, "current_track", 0)+1) % len(self.tracks)
            self.start_track()

    def start_track(self):
        self.player.setSource(QUrl.fromLocalFile(self.tracks[self.current_track])); self.player.play()
        self.now.setText("♫   " + Path(self.tracks[self.current_track]).stem); self.play_btn.setText("Ⅱ")

    def update_position(self, p):
        d = self.player.duration()
        if d > 0 and not self.position.isSliderDown():
            self.position.setValue(int(p*1000/d))

    def update_duration(self, d):
        pass

    def seek(self, value):
        d = self.player.duration()
        if d > 0: self.player.setPosition(int(d*value/1000))

    def open_url(self, url):
        if WEB_OK and hasattr(self, "web"):
            self.show_page(6); self.web.setUrl(QUrl(url))
        else:
            import webbrowser; webbrowser.open(url)

    def add_link(self):
        url = self.link_input.text().strip()
        if not url.startswith(("https://", "http://")):
            QMessageBox.warning(self, "Некорректная ссылка", "Вставь полную ссылку, начинающуюся с https:// или http://")
            return
        provider = self.provider_name(url)
        self.links.append({"url":url, "provider":provider})
        self.save_links(); self.link_input.clear(); self.refresh_links()

    def provider_name(self, url):
        u=url.lower()
        for domain, name in [("music.yandex","Яндекс Музыка"),("soundcloud","SoundCloud"),("spotify","Spotify"),("youtube","YouTube"),("youtu.be","YouTube"),("vk.com","VK Музыка")]:
            if domain in u: return name
        return "Ссылка"

    def refresh_links(self):
        if not hasattr(self, "link_list"): return
        self.link_list.clear()
        for item in self.links:
            self.link_list.addItem(f"{item.get('provider','Ссылка')}   ·   {item.get('url','')}")

    def selected_link_index(self):
        return self.link_list.currentRow()

    def open_selected_link(self, *args):
        i=self.selected_link_index()
        if i < 0 or i >= len(self.links): return
        url=self.links[i]["url"]
        if WEB_OK:
            self.show_page(6); self.web.setUrl(QUrl(url))
        else:
            import webbrowser; webbrowser.open(url)

    def remove_link(self):
        i=self.selected_link_index()
        if i >= 0:
            self.links.pop(i); self.save_links(); self.refresh_links()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("itackss")
    w = PlayerWindow(); w.show()
    sys.exit(app.exec())
