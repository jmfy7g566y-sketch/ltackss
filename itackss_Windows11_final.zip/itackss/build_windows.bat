@echo off
chcp 65001 >nul
python -m pip install --upgrade pip
python -m pip install -r requirements.txt pyinstaller
python -m PyInstaller --noconfirm --windowed --name itackss --collect-all PySide6 --collect-all shiboken6 main.py
echo.
echo Готово. Приложение находится в папке dist\itackss\itackss.exe
pause
